export class CSVRecord {
    public firstName: string;
    public lastName: any;
    public emailId: any;
    public position: any;
    public skills: any;
    public mobile: any;
    public location: any;   
  }
